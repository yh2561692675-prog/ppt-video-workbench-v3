from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import insert, select, update
from sqlalchemy.engine import RowMapping

from workbench.domain.enums import JobType, NodeStatus
from workbench.domain.models import JobRecord
from workbench.storage.workspace_db import WorkspaceDatabase, jobs


@dataclass(frozen=True)
class JobSpec:
    project_id: UUID
    job_type: JobType
    cache_key: str
    page_id: UUID | None = None
    paid: bool = False
    max_attempts: int | None = None


class JobRepository:
    def __init__(self, database: WorkspaceDatabase) -> None:
        self.database = database

    def enqueue(self, spec: JobSpec) -> UUID:
        with self.database.engine.begin() as connection:
            existing = connection.execute(
                select(jobs.c.id).where(
                    jobs.c.project_id == str(spec.project_id),
                    jobs.c.cache_key == spec.cache_key,
                )
            ).scalar_one_or_none()
            if existing is not None:
                return UUID(existing)

            now = _utc_now()
            job_id = uuid4()
            configured_attempts = spec.max_attempts or 3
            max_attempts = min(configured_attempts, 2) if spec.paid else configured_attempts
            connection.execute(
                insert(jobs).values(
                    id=str(job_id),
                    project_id=str(spec.project_id),
                    job_type=spec.job_type.value,
                    status=NodeStatus.NOT_STARTED.value,
                    cache_key=spec.cache_key,
                    page_id=str(spec.page_id) if spec.page_id else None,
                    progress=0.0,
                    attempts=0,
                    max_attempts=max_attempts,
                    paid=spec.paid,
                    error=None,
                    created_at=now,
                    updated_at=now,
                )
            )
        return job_id

    def get(self, job_id: UUID) -> JobRecord:
        with self.database.connect() as connection:
            row = connection.execute(select(jobs).where(jobs.c.id == str(job_id))).mappings().one()
        return _to_record(row)

    def list_all(self) -> list[JobRecord]:
        with self.database.connect() as connection:
            rows = connection.execute(select(jobs).order_by(jobs.c.created_at)).mappings().all()
        return [_to_record(row) for row in rows]

    def mark_running(self, job_id: UUID) -> JobRecord:
        return self._update(job_id, status=NodeStatus.RUNNING.value, error=None)

    def set_progress(self, job_id: UUID, progress: float) -> JobRecord:
        if not 0.0 <= progress <= 1.0:
            raise ValueError("progress must be between zero and one")
        return self._update(job_id, progress=progress)

    def record_attempt(self, job_id: UUID, error: str | None = None) -> JobRecord:
        record = self.get(job_id)
        return self._update(job_id, attempts=record.attempts + 1, error=error)

    def complete(self, job_id: UUID) -> JobRecord:
        return self._update(job_id, status=NodeStatus.COMPLETED.value, progress=1.0, error=None)

    def fail(self, job_id: UUID, error: str) -> JobRecord:
        return self._update(job_id, status=NodeStatus.FAILED.value, error=error)

    def pause(self, job_id: UUID) -> JobRecord:
        return self._update(job_id, status=NodeStatus.PAUSED.value)

    def resume(self, job_id: UUID) -> JobRecord:
        record = self.get(job_id)
        if record.status is not NodeStatus.PAUSED:
            return record
        return self._update(job_id, status=NodeStatus.NOT_STARTED.value, error=None)

    def requeue_for_recovery(self, job_id: UUID) -> JobRecord:
        record = self.get(job_id)
        if record.status is NodeStatus.COMPLETED:
            return record
        return self._update(
            job_id,
            status=NodeStatus.NOT_STARTED.value,
            error=None,
            attempts=0,
        )

    def recover_interrupted_jobs(self) -> list[JobRecord]:
        with self.database.engine.begin() as connection:
            interrupted_ids = list(
                connection.execute(
                    select(jobs.c.id).where(jobs.c.status == NodeStatus.RUNNING.value)
                ).scalars()
            )
            if interrupted_ids:
                connection.execute(
                    update(jobs)
                    .where(jobs.c.id.in_(interrupted_ids))
                    .values(status=NodeStatus.PAUSED.value, updated_at=_utc_now())
                )
        return [self.get(UUID(job_id)) for job_id in interrupted_ids]

    def _update(self, job_id: UUID, **values: object) -> JobRecord:
        values["updated_at"] = _utc_now()
        with self.database.engine.begin() as connection:
            result = connection.execute(
                update(jobs).where(jobs.c.id == str(job_id)).values(**values)
            )
            if result.rowcount != 1:
                raise KeyError(job_id)
        return self.get(job_id)


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()


def _to_record(row: RowMapping) -> JobRecord:
    payload: dict[str, Any] = dict(row)
    return JobRecord.model_validate(payload)
