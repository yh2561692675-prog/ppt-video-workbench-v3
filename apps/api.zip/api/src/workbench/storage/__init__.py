"""Persistent local storage."""
