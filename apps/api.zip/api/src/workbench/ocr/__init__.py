"""OCR adapters."""
