"""Core domain contracts."""
