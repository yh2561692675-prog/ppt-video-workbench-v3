from __future__ import annotations

import hashlib
import json
import os
import subprocess
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from PIL import Image

from .models import ProjectVideoProps, VideoPageProps


class PageRenderer(Protocol):
    def render(
        self,
        props: ProjectVideoProps,
        page: VideoPageProps,
        source: Path,
        output: Path,
    ) -> None: ...


class RenderError(RuntimeError):
    pass


@dataclass(frozen=True)
class RenderedPage:
    page_order: int
    path: Path
    cache_key: str
    cached: bool


class PillowPageRenderer:
    def render(
        self,
        _: ProjectVideoProps,
        __: VideoPageProps,
        source: Path,
        output: Path,
    ) -> None:
        with Image.open(source) as opened:
            image = opened.convert("RGB")
            image.thumbnail((1920, 1080), Image.Resampling.LANCZOS)
            canvas = Image.new("RGB", (1920, 1080), (7, 17, 31))
            left = (1920 - image.width) // 2
            top = (1080 - image.height) // 2
            canvas.paste(image, (left, top))
            output.parent.mkdir(parents=True, exist_ok=True)
            canvas.save(output, format="PNG", optimize=True)


class RemotionPageRenderer:
    def __init__(
        self,
        project_root: Path,
        *,
        remotion_root: Path | None = None,
        browser_executable: str | None = None,
        run: Callable[[list[str], Path], None] | None = None,
    ) -> None:
        self.project_root = project_root.resolve()
        self.remotion_root = (remotion_root or Path(__file__).resolve().parents[5]).resolve()
        self.browser_executable = browser_executable or os.environ.get(
            "WORKBENCH_REMOTION_BROWSER_EXECUTABLE"
        )
        self.run = run or self._run

    def render(
        self,
        props: ProjectVideoProps,
        page: VideoPageProps,
        _: Path,
        output: Path,
    ) -> None:
        output.parent.mkdir(parents=True, exist_ok=True)
        props_path = output.with_name(f".{output.stem}.props.json")
        props_path.write_text(
            json.dumps({"props": props.model_dump(mode="json")}, ensure_ascii=False),
            encoding="utf-8",
        )
        start_frame = (page.start_ms * props.fps + 500) // 1_000
        end_frame = (page.end_ms * props.fps + 500) // 1_000 - 1
        command = [
            "pnpm",
            "--filter",
            "@workbench/remotion",
            "exec",
            "remotion",
            "render",
            str(self.remotion_root / "remotion" / "src" / "index.ts"),
            "PptVideoWorkbench",
            str(output),
            f"--props={props_path}",
            f"--frames={start_frame}-{end_frame}",
            f"--public-dir={self.project_root}",
            "--codec=h264",
            "--muted",
            "--concurrency=1",
            "--log=error",
        ]
        if self.browser_executable:
            command.append(f"--browser-executable={self.browser_executable}")
            command.append("--chrome-mode=chrome-for-testing")
        try:
            self.run(command, self.remotion_root)
        finally:
            props_path.unlink(missing_ok=True)

    @staticmethod
    def _run(command: list[str], cwd: Path) -> None:
        completed = subprocess.run(command, cwd=cwd, check=False, capture_output=True, text=True)
        if completed.returncode != 0:
            raise RenderError("Remotion 页面渲染失败")


class VideoRenderService:
    def __init__(self, project_root: Path, renderer: PageRenderer | None = None) -> None:
        self.project_root = project_root.resolve()
        self.renderer = renderer or RemotionPageRenderer(self.project_root)
        self.cache_path = self.project_root / "07_视频工程" / "page-cache.json"
        self.output_dir = self.project_root / "07_视频工程" / "pages"

    def render_pages(self, props: ProjectVideoProps) -> list[RenderedPage]:
        cache = self._read_cache()
        results: list[RenderedPage] = []
        for page in props.pages:
            source = self._safe_path(page.image_path)
            if not source.is_file():
                raise RenderError(f"第{page.page_order}页预览图不存在")
            output = self.output_dir / f"page-{page.page_order:04d}.mp4"
            cache_key = self._cache_key(props, page, source)
            record = cache.get(str(page.page_order))
            if (
                isinstance(record, dict)
                and record.get("cache_key") == cache_key
                and output.is_file()
            ):
                results.append(
                    RenderedPage(page.page_order, output, cache_key, True)
                )
                continue
            try:
                temporary = output.with_name(f".{output.stem}.tmp.mp4")
                self.renderer.render(props, page, source, temporary)
                if not temporary.is_file() or temporary.stat().st_size == 0:
                    raise RenderError("页面渲染结果为空")
                os.replace(temporary, output)
            except Exception as error:
                temporary.unlink(missing_ok=True)
                if isinstance(error, RenderError):
                    raise RenderError(f"第{page.page_order}页渲染失败：{error}") from error
                raise RenderError(f"第{page.page_order}页渲染失败：{error}") from error
            cache[str(page.page_order)] = {
                "cache_key": cache_key,
                "relative_path": str(output.relative_to(self.project_root)),
            }
            self._write_cache(cache)
            results.append(RenderedPage(page.page_order, output, cache_key, False))
        return results

    def _safe_path(self, relative_path: str) -> Path:
        target = (self.project_root / relative_path).resolve()
        if self.project_root not in target.parents:
            raise RenderError("页面预览图路径超出项目目录")
        return target

    def _cache_key(self, props: ProjectVideoProps, page: VideoPageProps, source: Path) -> str:
        digest = hashlib.sha256()
        digest.update(props.template_version.encode("utf-8"))
        digest.update(
            json.dumps(
                {
                    "page": page.model_dump(mode="json"),
                    "subtitles": [
                        cue.model_dump(mode="json")
                        for cue in props.subtitles
                        if cue.page_id == page.page_id
                    ],
                    "placement": next(
                        (
                            placement.model_dump(mode="json")
                            for placement in props.subtitle_placements
                            if placement.page_id == page.page_id
                        ),
                        None,
                    ),
                    "reduced_motion": props.reduced_motion,
                },
                ensure_ascii=False,
                sort_keys=True,
            ).encode("utf-8")
        )
        digest.update(hashlib.sha256(source.read_bytes()).digest())
        return digest.hexdigest()

    def _read_cache(self) -> dict[str, object]:
        if not self.cache_path.is_file():
            return {}
        try:
            payload = json.loads(self.cache_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return {}
        return payload if isinstance(payload, dict) else {}

    def _write_cache(self, cache: dict[str, object]) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.cache_path.with_name(f".{self.cache_path.name}.tmp")
        temporary.write_text(
            json.dumps(cache, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, self.cache_path)
