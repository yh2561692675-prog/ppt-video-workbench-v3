from __future__ import annotations

from pathlib import Path
from uuid import UUID

from workbench.audio.service import AudioService
from workbench.domain.models import ProjectManifest
from workbench.subtitles.models import SubtitleTimeline
from workbench.video.models import ProjectVideoProps, VideoPageProps


class VideoPropsService:
    def __init__(self, audio: AudioService) -> None:
        self.audio = audio

    def build(
        self,
        project: ProjectManifest,
        subtitles: SubtitleTimeline,
    ) -> ProjectVideoProps:
        page_audio = {item.page_id: item for item in self.audio.resolve_page_audio(project)}
        segments = (
            {segment.page_id: segment for segment in project.audio_timeline.segments}
            if project.audio_timeline is not None
            else {}
        )
        pages = []
        cursor_ms = 0
        for page in sorted(project.pages, key=lambda item: item.order):
            audio = page_audio[page.id]
            segment = segments.get(page.id)
            if segment is None:
                start_ms, end_ms = cursor_ms, cursor_ms + audio.duration_ms
            else:
                start_ms, end_ms = segment.start_ms, segment.end_ms
            pages.append(
                VideoPageProps(
                    page_id=page.id,
                    page_order=page.order,
                    title=page.title or "",
                    image_path=self._page_image_path(project, page.id),
                    audio_path=audio.path,
                    start_ms=start_ms,
                    end_ms=end_ms,
                    subtitle_cue_ids=[
                        cue.id for cue in subtitles.cues if cue.page_id == page.id
                    ],
                )
            )
            cursor_ms = end_ms
        return ProjectVideoProps(
            project_id=project.id,
            duration_ms=subtitles.duration_ms,
            template_version="tech-board-v1",
            pages=pages,
            subtitles=subtitles.cues,
        )

    def _page_image_path(self, project: ProjectManifest, page_id: UUID) -> str:
        extraction = next(
            (
                item
                for item in project.page_extractions
                if (page_source_id := next(
                    (page.source_file_id for page in project.pages if page.id == page_id), None
                ))
                and item.id == page_source_id
            ),
            None,
        )
        if extraction is None:
            page = next((item for item in project.pages if item.id == page_id), None)
            extraction = next(
                (item for item in project.page_extractions if page and item.order == page.order),
                None,
            )
        if extraction is None or extraction.preview_path is None:
            raise ValueError("页面缺少可用于视频的预览图")
        root = (self.audio.workspace_root / project.project_dir).resolve()
        path = Path(extraction.preview_path).resolve()
        if root not in path.parents:
            raise ValueError("页面预览图路径超出项目目录")
        return str(path.relative_to(root))
