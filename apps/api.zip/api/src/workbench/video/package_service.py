from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field

from workbench.domain.enums import NodeStatus
from workbench.domain.issues import PreflightReport
from workbench.domain.models import AuditEvent, ProjectManifest, VideoExportRecord
from workbench.exports.narration_docx import export_narration_docx
from workbench.services.project_service import ProjectService

from .preview_service import VideoPreviewService
from .render_service import PageRenderer, RenderError, VideoRenderService


class PackageError(ValueError):
    pass


class PackageArtifact(BaseModel):
    model_config = ConfigDict(extra="forbid")

    relative_path: str
    size: int = Field(ge=0)
    sha256: str = Field(min_length=64, max_length=64)


class PackageManifest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    version: int = 1
    artifacts: list[PackageArtifact] = Field(min_length=1)


class VideoExportBlocked(RuntimeError):
    pass


class VideoExportError(RuntimeError):
    pass


class VideoExportResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    mp4_relative_path: str
    package_relative_path: str
    duration_ms: int = Field(ge=0)
    width: int = 1920
    height: int = 1080
    video_codec: str
    audio_codec: str
    artifact_count: int = Field(ge=1)
    cached_pages: int = Field(ge=0)


MEDIA_DURATION_TOLERANCE_MS = 100


class VideoExportService:
    def __init__(
        self,
        projects: ProjectService,
        preview: VideoPreviewService,
        ffmpeg: str = "ffmpeg",
        ffprobe: str = "ffprobe",
        renderer: PageRenderer | None = None,
        preflight_gate: Callable[[UUID], PreflightReport] | None = None,
    ) -> None:
        self.projects = projects
        self.preview = preview
        self.ffmpeg = ffmpeg
        self.ffprobe = ffprobe
        self.renderer = renderer
        self.preflight_gate = preflight_gate

    def mark_failed(self, project_id: UUID, *, error_code: str) -> None:
        project = self.projects.get(project_id)
        now = datetime.now(UTC)
        self.projects.save(
            project.model_copy(
                update={
                    "video_export": VideoExportRecord(
                        id=uuid4(),
                        status=NodeStatus.FAILED,
                        duration_ms=0,
                        artifact_count=0,
                        error_code=error_code,
                        exported_at=now,
                    ),
                    "audit_log": [
                        *project.audit_log,
                        AuditEvent(
                            action="video_export_failed",
                            occurred_at=now,
                            details={"error_code": error_code},
                        ),
                    ],
                }
            )
        )

    def export(self, project_id: UUID) -> VideoExportResult:
        project = self.projects.get(project_id)
        try:
            if self.preflight_gate is not None:
                report = self.preflight_gate(project_id)
                if not report.allowed:
                    raise VideoExportBlocked("当前项目预检尚未通过")
            return self._export(project_id, project)
        except VideoExportBlocked:
            raise
        except (VideoExportError, RenderError, PackageError):
            self.mark_failed(project_id, error_code="video_export_rejected")
            raise
        except Exception as error:
            self.mark_failed(project_id, error_code="video_export_rejected")
            raise VideoExportError("视频导出失败，请检查渲染环境和制作素材") from error

    def _export(self, project_id: UUID, project: ProjectManifest) -> VideoExportResult:
        preflight = self.preview.preflight(project_id)
        if not preflight.allowed or preflight.props is None:
            raise VideoExportBlocked("视频完整预检尚未通过")
        props = preflight.props
        root = (self.projects.workspace_root / project.project_dir).resolve()
        rendered = VideoRenderService(root, self.renderer).render_pages(props)
        segments_dir = root / "07_视频工程" / "segments"
        segments_dir.mkdir(parents=True, exist_ok=True)
        segments = []
        for page, rendered_page in zip(props.pages, rendered, strict=True):
            segment = segments_dir / f"page-{page.page_order:04d}.mp4"
            audio = self._safe_path(root, page.audio_path)
            if not audio.is_file():
                raise VideoExportError(f"第{page.page_order}页音频文件不存在")
            duration = (page.end_ms - page.start_ms) / 1_000
            self._run_ffmpeg(
                [
                    self.ffmpeg,
                    "-y",
                    "-loglevel",
                    "error",
                    "-i",
                    str(rendered_page.path),
                    "-i",
                    str(audio),
                    "-t",
                    f"{duration:.3f}",
                    "-map",
                    "0:v:0",
                    "-map",
                    "1:a:0",
                    "-c:v",
                    "libx264",
                    "-pix_fmt",
                    "yuv420p",
                    "-c:a",
                    "aac",
                    "-b:a",
                    "128k",
                    "-shortest",
                    str(segment),
                ],
                root,
            )
            validate_media_probe(
                self._probe(segment),
                expected_duration_ms=page.end_ms - page.start_ms,
                tolerance_ms=MEDIA_DURATION_TOLERANCE_MS,
            )
            segments.append(segment)

        output_dir = root / "08_输出"
        output_dir.mkdir(parents=True, exist_ok=True)
        final_mp4 = output_dir / "最终视频.mp4"
        concat_file = segments_dir / "concat.txt"
        concat_file.write_text(
            "".join(f"file '{segment.name}'\n" for segment in segments), encoding="utf-8"
        )
        self._run_ffmpeg(
            [
                self.ffmpeg,
                "-y",
                "-loglevel",
                "error",
                "-f",
                "concat",
                "-safe",
                "0",
                "-i",
                str(concat_file),
                "-c",
                "copy",
                str(final_mp4),
            ],
            segments_dir,
        )
        probe = self._probe(final_mp4)
        validate_media_probe(
            probe,
            expected_duration_ms=props.duration_ms,
            tolerance_ms=MEDIA_DURATION_TOLERANCE_MS,
        )
        measured_duration_ms = probe.get("duration_ms")
        if not isinstance(measured_duration_ms, int):
            raise VideoExportError("成片时长无法读取")

        package = output_dir / "制作包"
        package.mkdir(parents=True, exist_ok=True)
        shutil.copy2(final_mp4, package / "最终视频.mp4")
        srt = root / "06_字幕" / "字幕.srt"
        if not srt.is_file():
            raise VideoExportError("缺少字幕 SRT")
        shutil.copy2(srt, package / "字幕.srt")
        narration = export_narration_docx(project, root)
        shutil.copy2(narration, package / "旁白确认版.docx")
        audio_dir = package / "分页音频"
        audio_dir.mkdir(parents=True, exist_ok=True)
        for page in props.pages:
            audio = self._safe_path(root, page.audio_path)
            shutil.copy2(audio, audio_dir / f"page-{page.page_order:04d}.wav")
        remotion_dir = package / "Remotion工程"
        remotion_dir.mkdir(parents=True, exist_ok=True)
        (remotion_dir / "ProjectVideoProps.json").write_text(
            props.model_dump_json(indent=2) + "\n", encoding="utf-8"
        )
        (package / "预检报告.json").write_text(
            preflight.model_dump_json(indent=2) + "\n", encoding="utf-8"
        )
        (package / "日志清单.json").write_text(
            json.dumps(
                {"events": ["page_rendered", "ffmpeg_composed", "package_validated"]},
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        (package / "render.config.json").write_text(
            json.dumps(
                {"width": props.width, "height": props.height, "fps": props.fps},
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        artifact_paths = sorted(
            (path for path in package.rglob("*") if path.is_file()),
            key=lambda path: path.relative_to(package).as_posix(),
        )
        manifest = build_package_manifest(package, artifact_paths)
        (package / "制作包清单.json").write_text(
            manifest.model_dump_json(indent=2) + "\n", encoding="utf-8"
        )
        result = VideoExportResult(
            mp4_relative_path="08_输出/最终视频.mp4",
            package_relative_path="08_输出/制作包",
            duration_ms=measured_duration_ms,
            video_codec="h264",
            audio_codec="aac",
            artifact_count=len(manifest.artifacts) + 1,
            cached_pages=sum(item.cached for item in rendered),
        )
        latest = self.projects.get(project_id)
        self.projects.save(
            latest.model_copy(
                update={
                    "video_export": VideoExportRecord(
                        id=uuid4(),
                        status=NodeStatus.COMPLETED,
                        mp4_relative_path=result.mp4_relative_path,
                        package_relative_path=result.package_relative_path,
                        duration_ms=result.duration_ms,
                        artifact_count=result.artifact_count,
                        exported_at=datetime.now(UTC),
                    )
                }
            )
        )
        return result

    def _run_ffmpeg(self, command: list[str], cwd: Path) -> None:
        try:
            completed = subprocess.run(
                command,
                cwd=cwd,
                check=False,
                capture_output=True,
                text=True,
            )
        except OSError as error:
            raise VideoExportError("未找到 FFmpeg，请先安装并加入 PATH") from error
        if completed.returncode != 0:
            raise VideoExportError("FFmpeg 合成失败，请检查视频日志")

    def _probe(self, path: Path) -> dict[str, object]:
        try:
            completed = subprocess.run(
                [
                    self.ffprobe,
                    "-v",
                    "error",
                    "-show_entries",
                    "format=duration:stream=codec_name,width,height",
                    "-of",
                    "json",
                    str(path),
                ],
                check=False,
                capture_output=True,
                text=True,
            )
        except OSError as error:
            raise VideoExportError("未找到 FFprobe，请先安装并加入 PATH") from error
        if completed.returncode != 0:
            raise VideoExportError("无法校验最终视频")
        payload = json.loads(completed.stdout)
        streams: list[dict[str, object]] = payload.get("streams", [])
        format_data = payload.get("format", {})
        video: dict[str, object] = next(
            (item for item in streams if item.get("width") is not None), {}
        )
        audio: dict[str, object] = next(
            (item for item in streams if item.get("codec_name") == "aac"), {}
        )
        return {
            "width": video.get("width"),
            "height": video.get("height"),
            "video_codec": video.get("codec_name"),
            "audio_codec": audio.get("codec_name"),
            "duration_ms": round(float(format_data.get("duration", 0)) * 1_000),
        }

    @staticmethod
    def _safe_path(root: Path, relative_path: str) -> Path:
        target = (root / relative_path).resolve()
        if root not in target.parents:
            raise VideoExportError("视频资源路径超出项目目录")
        return target


def build_package_manifest(root: Path, paths: list[Path]) -> PackageManifest:
    package_root = root.resolve()
    artifacts: list[PackageArtifact] = []
    for path in paths:
        target = path.resolve()
        if package_root not in target.parents:
            raise PackageError(f"文件超出制作包目录：{path}")
        if not target.is_file():
            raise PackageError(f"缺少制作包文件：{path}")
        artifacts.append(
            PackageArtifact(
                relative_path=target.relative_to(package_root).as_posix(),
                size=target.stat().st_size,
                sha256=_sha256(target),
            )
        )
    if not artifacts:
        raise PackageError("制作包没有可交付文件")
    return PackageManifest(artifacts=artifacts)


def validate_media_probe(
    probe: dict[str, object], *, expected_duration_ms: int, tolerance_ms: int
) -> None:
    expected = {"width": 1920, "height": 1080, "video_codec": "h264", "audio_codec": "aac"}
    observed = {key: probe.get(key) for key in expected}
    if observed != expected:
        raise VideoExportError(f"成片编码或画布不符合契约：{observed}")
    duration_ms = probe.get("duration_ms")
    if not isinstance(duration_ms, int) or abs(duration_ms - expected_duration_ms) > tolerance_ms:
        raise VideoExportError(
            f"成片时长不符合契约：实际 {duration_ms}ms，预期 {expected_duration_ms}ms"
        )


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()
