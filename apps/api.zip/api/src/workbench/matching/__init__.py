"""Deterministic material matching."""
